@echo off
title Bilibili Transcript Tool

echo ==============================
echo   Bilibili Transcript Tool
echo ==============================
echo.

cd /d "%~dp0"

python --version >nul 2>&1
if errorlevel 1 (
    echo [ERROR] Python not found. Please install Python 3.11+ first:
    echo         https://www.python.org/downloads/
    echo         IMPORTANT: check "Add python.exe to PATH" during install!
    pause
    exit /b 1
)

ffmpeg -version >nul 2>&1
if errorlevel 1 (
    echo [WARNING] ffmpeg not found. Installing via winget...
    winget install --id Gyan.FFmpeg -e --accept-source-agreements --accept-package-agreements
    echo Please RESTART this script after ffmpeg installation completes.
    pause
    exit /b 0
)

echo Checking Python packages (first run may take a few minutes)...
python -m pip install -q flask yt-dlp openai-whisper requests transformers
if errorlevel 1 (
    echo [ERROR] Package installation failed. Check your network connection.
    pause
    exit /b 1
)

echo.
echo Starting server... Browser will open at http://localhost:5000
echo Press Ctrl+C to stop.
echo.

start /b cmd /c "timeout /t 3 >nul && start http://localhost:5000"

python app.py

pause
