Dim WshShell, fso, appDir, appPy, candidates, i, found

Set WshShell = CreateObject("WScript.Shell")
Set fso = CreateObject("Scripting.FileSystemObject")

appDir = fso.GetParentFolderName(WScript.ScriptFullName)
appPy = appDir & "\app.py"

If Not fso.FileExists(appPy) Then
    MsgBox "app.py not found. Keep this script in the same folder as app.py.", 16, "Error"
    WScript.Quit
End If

found = ""
candidates = Array( _
    WshShell.ExpandEnvironmentStrings("%LOCALAPPDATA%") & "\Python\pythoncore-3.14-64\pythonw.exe", _
    WshShell.ExpandEnvironmentStrings("%LOCALAPPDATA%") & "\Programs\Python\Python313\pythonw.exe", _
    WshShell.ExpandEnvironmentStrings("%LOCALAPPDATA%") & "\Programs\Python\Python312\pythonw.exe", _
    WshShell.ExpandEnvironmentStrings("%LOCALAPPDATA%") & "\Programs\Python\Python311\pythonw.exe" _
)

For i = 0 To UBound(candidates)
    If fso.FileExists(candidates(i)) Then
        found = candidates(i)
        Exit For
    End If
Next

WshShell.CurrentDirectory = appDir

If found <> "" Then
    WshShell.Run """" & found & """ """ & appPy & """", 0, False
Else
    WshShell.Run "cmd /c start /min """" python """ & appPy & """", 0, False
End If

WScript.Sleep 3000
WshShell.Run "http://localhost:5000"
