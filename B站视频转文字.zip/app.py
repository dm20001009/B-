"""
B站视频逐字稿生成 Web 应用
- 自动从 B 站 API 获取临时 Cookie（公开视频无需手动导出）
- 优先提取 B 站内置字幕，无字幕时用 Whisper 转录
- Whisper 输出自动带标点
"""

import os, json, uuid, threading, tempfile, time
from flask import Flask, render_template, request, jsonify, Response, stream_with_context

app = Flask(__name__)
tasks = {}

COOKIES_FILE = os.path.join(os.path.dirname(__file__), "cookies.txt")
UA = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/125.0.0.0 Safari/537.36"


def update_task(task_id, **kwargs):
    if task_id in tasks:
        tasks[task_id].update(kwargs)


def fetch_auto_cookies(tmpdir):
    """
    完整 B 站 Cookie 初始化（绕过 412 的三步流程）：
    1. 访问首页获取初始 cookie
    2. 调用 finger/spi 获取 buvid3/buvid4
    3. 向 ExClimbWuzhi 注册指纹（此步是关键，缺少会 412）
    """
    import requests, json as _json

    session = requests.Session()
    base_headers = {
        "User-Agent": UA,
        "Referer": "https://www.bilibili.com",
        "Origin": "https://www.bilibili.com",
        "Accept-Language": "zh-CN,zh;q=0.9",
    }
    session.headers.update(base_headers)

    # 步骤1：访问首页
    try:
        session.get("https://www.bilibili.com", timeout=10)
    except Exception:
        pass

    # 步骤2：获取 buvid3 / buvid4
    try:
        r = session.get("https://api.bilibili.com/x/frontend/finger/spi", timeout=6)
        data = r.json()
        if data.get("code") == 0:
            buvid3 = data["data"].get("b_3", "")
            buvid4 = data["data"].get("b_4", "")
            if buvid3:
                session.cookies.set("buvid3", buvid3, domain=".bilibili.com", path="/")
            if buvid4:
                session.cookies.set("buvid4", buvid4, domain=".bilibili.com", path="/")
    except Exception:
        pass

    # 步骤3：注册指纹（关键！不做此步会 412）
    try:
        payload = _json.dumps({
            "3064": 1,
            "5062": str(int(time.time() * 1000)),
            "03bf": "https://www.bilibili.com/",
            "c3b4": "24",
            "6bc5": "zh-CN",
            "07a4": "zh-CN",
            "b8ce": UA,
        })
        session.post(
            "https://api.bilibili.com/x/internal/gaia-gateway/ExClimbWuzhi",
            json={"payload": payload},
            headers={**base_headers, "Content-Type": "application/json;charset=UTF-8"},
            timeout=6,
        )
    except Exception:
        pass

    if not session.cookies:
        return None

    cookie_path = os.path.join(tmpdir, "auto_cookies.txt")
    expire = int(time.time()) + 86400 * 365
    lines = ["# Netscape HTTP Cookie File\n"]
    for c in session.cookies:
        domain = c.domain or ".bilibili.com"
        if not domain.startswith("."):
            domain = "." + domain
        exp = int(c.expires) if c.expires else expire
        secure = "TRUE" if c.secure else "FALSE"
        lines.append(f"{domain}\tTRUE\t/\t{secure}\t{exp}\t{c.name}\t{c.value}\n")

    with open(cookie_path, "w", encoding="utf-8") as f:
        f.writelines(lines)
    return cookie_path


def normalize_bili_url(url):
    """
    把各种 B 站链接（稍后再看/收藏夹/分享短链等）统一转成标准视频链接。
    稍后再看等列表链接必须登录才能访问，转成标准链接后公开视频可直接下载。
    """
    import re
    m = re.search(r"(BV[0-9A-Za-z]{10})", url)
    if m:
        return f"https://www.bilibili.com/video/{m.group(1)}"
    m = re.search(r"av(\d+)", url, re.IGNORECASE)
    if m:
        return f"https://www.bilibili.com/video/av{m.group(1)}"
    return url


def cookies_file_valid():
    """cookies.txt 必须含 SESSDATA（登录凭证）才算有效，否则忽略"""
    if not os.path.exists(COOKIES_FILE):
        return False
    try:
        with open(COOKIES_FILE, encoding="utf-8", errors="ignore") as f:
            return "SESSDATA" in f.read()
    except Exception:
        return False


def get_ydl_base_opts(tmpdir, auto_cookie_path=None):
    opts = {
        "outtmpl": os.path.join(tmpdir, "audio.%(ext)s"),
        "quiet": True,
        "no_warnings": True,
        "http_headers": {
            "User-Agent": UA,
            "Referer": "https://www.bilibili.com",
        },
    }
    # 有效的登录 cookies 优先；无效则用自动获取的
    if cookies_file_valid():
        opts["cookiefile"] = COOKIES_FILE
    elif auto_cookie_path and os.path.exists(auto_cookie_path):
        opts["cookiefile"] = auto_cookie_path
    return opts


def try_get_subtitle(url, tmpdir, task_id, auto_cookie_path):
    """尝试直接提取 B 站内置字幕，返回 (title, text) 或 (title, None)"""
    import yt_dlp

    sub_dir = os.path.join(tmpdir, "subs")
    os.makedirs(sub_dir, exist_ok=True)

    sub_opts = {
        **get_ydl_base_opts(tmpdir, auto_cookie_path),
        "outtmpl": os.path.join(sub_dir, "sub.%(ext)s"),
        "writesubtitles": True,
        "writeautomaticsub": True,
        "subtitleslangs": ["zh-Hans", "zh", "ai-zh", "en"],
        "subtitlesformat": "json3/srt/best",
        "skip_download": True,
    }

    with yt_dlp.YoutubeDL(sub_opts) as ydl:
        info = ydl.extract_info(url, download=True)
        title = info.get("title", "unknown")
        update_task(task_id, title=title)

    sub_text = None
    for f in os.listdir(sub_dir):
        fpath = os.path.join(sub_dir, f)
        text = parse_subtitle_file(fpath)
        if text and len(text.strip()) > 20:
            sub_text = text
            break
    return title, sub_text


def parse_subtitle_file(path):
    text_parts = []
    if path.endswith(".json3"):
        with open(path, encoding="utf-8") as f:
            data = json.load(f)
        for event in data.get("events", []):
            for seg in event.get("segs", []):
                t = seg.get("utf8", "").strip()
                if t and t != "\n":
                    text_parts.append(t)
    elif path.endswith((".srt", ".vtt")):
        import re
        with open(path, encoding="utf-8") as f:
            raw = f.read()
        for line in raw.splitlines():
            line = line.strip()
            if not line or re.match(r"^\d+$", line) or re.match(r"[\d:,\. ]+-->", line) or line.startswith("WEBVTT"):
                continue
            text_parts.append(line)
    return "".join(text_parts) if text_parts else None


def download_audio(url, tmpdir, task_id, auto_cookie_path):
    import yt_dlp

    def hook(d):
        if d["status"] == "downloading":
            total = d.get("total_bytes") or d.get("total_bytes_estimate", 0)
            downloaded = d.get("downloaded_bytes", 0)
            if total:
                pct = int(downloaded / total * 30) + 30
                update_task(task_id, progress=pct,
                            message=f"下载中 {d.get('_percent_str','').strip()}  {d.get('_speed_str','').strip()}")
        elif d["status"] == "finished":
            update_task(task_id, progress=60, message="下载完成，准备转录...")

    opts = {
        **get_ydl_base_opts(tmpdir, auto_cookie_path),
        "format": "bestaudio/best",
        "postprocessors": [{"key": "FFmpegExtractAudio", "preferredcodec": "mp3", "preferredquality": "192"}],
        "progress_hooks": [hook],
    }
    with yt_dlp.YoutubeDL(opts) as ydl:
        info = ydl.extract_info(url, download=True)
        title = info.get("title", "unknown")
        update_task(task_id, title=title)

    audio_path = None
    for f in os.listdir(tmpdir):
        if f.startswith("audio."):
            audio_path = os.path.join(tmpdir, f)
            break
    return title, audio_path




def punctuate_from_segments(segments):
    """
    从 Whisper segments 时间停顿 + 语气词规则推断中文标点：
      停顿 > 1.5s → 新段落
      停顿 0.5~1.5s → 句号 / 问号 / 感叹号
      停顿 0.15~0.5s → 逗号 ，
    每 5 句合为一段。
    """
    import re

    # 疑问语气词 → ？
    Q_WORDS = re.compile(r'(吗|嘛|呢|吧|啊|哦|嗯|对吧|是吧|好吗|好不好|对不对|行吗|可以吗|怎么样)$')
    # 感叹语气词 → ！
    E_WORDS = re.compile(r'(啊|呀|哇|哈|耶|太好了|真棒|厉害|不错|加油)$')

    def end_mark(text):
        t = text.strip()
        if Q_WORDS.search(t):
            return '？'
        if E_WORDS.search(t):
            return '！'
        return '。'

    if not segments:
        return ""

    sentences, buf, prev_end = [], [], 0.0

    for seg in segments:
        text = seg.get("text", "").strip()
        if not text:
            prev_end = seg.get("end", prev_end)
            continue

        gap = seg["start"] - prev_end

        if buf and gap >= 1.5:
            joined = "".join(buf)
            if not re.search(r'[。！？；.!?]$', joined):
                joined += end_mark(joined)
            sentences.append(joined)
            buf = []
        elif buf and gap >= 0.5:
            if not re.search(r'[，。！？；]$', buf[-1]):
                buf.append("，")

        buf.append(text)
        prev_end = seg.get("end", prev_end)

    if buf:
        joined = "".join(buf)
        if not re.search(r'[。！？；.!?]$', joined):
            joined += end_mark(joined)
        sentences.append(joined)

    paragraphs, group = [], []
    for sent in sentences:
        group.append(sent)
        if len(group) >= 5:
            paragraphs.append("".join(group))
            group = []
    if group:
        paragraphs.append("".join(group))

    return "\n\n".join(paragraphs)


def finalize_text(raw, task_id=None):
    """
    统一的最终处理：
    1. 若文本几乎没有标点 → 用中文标点恢复模型补标点（首次下载约 400MB）
    2. 按句末标点分段，每 5 句一段
    """
    import re
    if not raw:
        return raw
    raw = raw.strip()

    # 计算标点密度：每 100 字少于 2 个标点视为"无标点"
    punct_count = len(re.findall(r'[，。！？；]', raw))
    density = punct_count / max(len(raw), 1) * 100

    if density < 2:
        if task_id:
            update_task(task_id, message="文本缺少标点，正在用 AI 模型恢复标点（首次需下载模型）...")
        try:
            from punctuate import restore_punctuation
            restored = restore_punctuation(raw)
            if restored and len(re.findall(r'[，。！？；]', restored)) > punct_count:
                raw = restored
        except Exception:
            pass

    # 分段
    text = re.sub(r'([。！？!?])\s*', r'\1\n', raw)
    lines = [l.strip() for l in text.splitlines() if l.strip()]
    paragraphs, group = [], []
    for line in lines:
        group.append(line)
        if len(group) >= 5:
            paragraphs.append("".join(group))
            group = []
    if group:
        paragraphs.append("".join(group))
    return "\n\n".join(paragraphs)


def run_transcript(task_id, url, model_size, language):
    try:
        tmpdir = tasks[task_id]["tmpdir"]

        # ── 1. 自动获取 B 站临时 Cookie ──────────────────────
        update_task(task_id, stage="cookie", progress=5, message="自动获取 B 站访问凭证...")
        auto_cookie_path = fetch_auto_cookies(tmpdir)

        # ── 2. 尝试提取内置字幕 ──────────────────────────────
        update_task(task_id, stage="subtitle", progress=12, message="检测视频内置字幕...")
        try:
            title, sub_text = try_get_subtitle(url, tmpdir, task_id, auto_cookie_path)
        except Exception as e:
            err = str(e)
            if "412" in err or "Precondition" in err:
                if cookies_file_valid():
                    update_task(task_id, stage="error", status="error", progress=0,
                                message="B 站拒绝访问（412）。cookies.txt 登录已过期，请重新导出替换后重试。")
                else:
                    update_task(task_id, stage="error", status="error", progress=0,
                                message="B 站拒绝访问（412）。请稍等几秒重试一次；若持续失败请检查网络。")
                return
            raise

        if sub_text and len(sub_text.strip()) > 20:
            update_task(task_id, progress=60, message="字幕提取成功，整理标点分段...")
            formatted = finalize_text(sub_text.strip(), task_id)
            update_task(task_id, stage="subtitle_done", status="success", progress=100,
                        message="已提取 B 站内置字幕并恢复标点", text=formatted)
            return

        # ── 3. 下载音频 ──────────────────────────────────────
        update_task(task_id, stage="downloading", progress=25,
                    message="该视频无内置字幕，正在下载音频...")
        title, audio_path = download_audio(url, tmpdir, task_id, auto_cookie_path)

        if not audio_path or not os.path.exists(audio_path):
            raise FileNotFoundError("音频下载失败，请检查链接是否有效")

        # ── 4. Whisper 转录（带标点提示）────────────────────
        import whisper
        update_task(task_id, stage="loading_model", progress=62,
                    message=f"加载 Whisper {model_size} 模型（首次需下载）...")
        model = whisper.load_model(model_size)

        update_task(task_id, stage="transcribing", progress=70, message="语音转文字中，请耐心等待...")

        lang = None if language == "auto" else language

        # initial_prompt 让 Whisper 输出带标点的中文
        if lang in (None, "zh"):
            initial_prompt = (
                "以下是普通话视频的转录稿，含完整中文标点。"
                "示例：大家好，欢迎来到本期视频。今天我们聊的话题是什么？让我来告诉你们！"
                "首先，我们需要了解几个基本概念。其次，要注意实际操作中的细节。"
            )
        else:
            initial_prompt = None

        result = model.transcribe(
            audio_path,
            language=lang,
            initial_prompt=initial_prompt,
            condition_on_previous_text=True,
            verbose=False,
            fp16=False,
        )
        raw_text = result["text"].strip()
        segments  = result.get("segments", [])

        update_task(task_id, stage="punctuating", progress=92,
                    message="正在整理标点和分段...")

        formatted = finalize_text(raw_text, task_id)
        # 标点模型也失败时的最后兜底：时间轴推断
        import re as _re
        if not _re.search(r'[，。！？；]', formatted):
            formatted = punctuate_from_segments(segments)

        update_task(task_id, stage="whisper_done", status="success", progress=100,
                    message="转录完成！", text=formatted)

    except Exception as e:
        update_task(task_id, stage="error", status="error", progress=0, message=str(e))


# ── Flask 路由 ────────────────────────────────────────────────

@app.route("/")
def index():
    return render_template("index.html", has_cookies=os.path.exists(COOKIES_FILE))


@app.route("/api/start", methods=["POST"])
def start_task():
    data = request.json
    url = data.get("url", "").strip()
    if not url:
        return jsonify({"error": "请输入视频链接"}), 400
    if "bilibili.com" not in url and "b23.tv" not in url:
        return jsonify({"error": "请输入有效的 B 站链接"}), 400
    url = normalize_bili_url(url)

    task_id = str(uuid.uuid4())
    tmpdir = tempfile.mkdtemp()
    tasks[task_id] = {
        "id": task_id, "url": url,
        "model": data.get("model", "medium"),
        "language": data.get("language", "zh"),
        "stage": "queued", "progress": 0,
        "message": "任务已创建...", "text": "", "title": "",
        "status": "running", "tmpdir": tmpdir,
    }
    threading.Thread(
        target=run_transcript,
        args=(task_id, url, data.get("model", "medium"), data.get("language", "zh")),
        daemon=True
    ).start()
    return jsonify({"task_id": task_id})


@app.route("/api/stream/<task_id>")
def task_stream(task_id):
    def generate():
        last, t = -1, 0
        while t < 600:
            task = tasks.get(task_id)
            if not task:
                break
            if task["progress"] != last or task["status"] in ("success", "error"):
                last = task["progress"]
                yield f"data: {json.dumps({k: task[k] for k in ('stage','progress','message','text','title','status')}, ensure_ascii=False)}\n\n"
            if task["status"] in ("success", "error"):
                break
            time.sleep(0.5)
            t += 0.5

    return Response(stream_with_context(generate()), mimetype="text/event-stream",
                    headers={"Cache-Control": "no-cache", "X-Accel-Buffering": "no"})


@app.route("/api/cookies_status")
def cookies_status():
    return jsonify({"has_cookies": cookies_file_valid()})


if __name__ == "__main__":
    port = int(os.environ.get("PORT", 5000))
    print("\n=== B站逐字稿生成工具 ===")
    print(f"访问: http://localhost:{port}")
    print("公开视频无需手动配置 Cookie，自动获取")
    app.run(debug=False, port=port, threaded=True)
