"""
中文标点恢复模块
使用 p208p2002/zh-wiki-punctuation-restore 模型（BERT token 分类）
直接调用 transformers，不依赖已失效的 pipeline 封装
"""

import re

_model = None
_tokenizer = None

# 模型输出标签 -> 标点
MODEL_NAME = "p208p2002/zh-wiki-punctuation-restore"


def _load():
    global _model, _tokenizer
    if _model is None:
        import torch
        from transformers import AutoTokenizer, AutoModelForTokenClassification
        _tokenizer = AutoTokenizer.from_pretrained(MODEL_NAME)
        _model = AutoModelForTokenClassification.from_pretrained(MODEL_NAME)
        _model.eval()
    return _model, _tokenizer


def _restore_chunk(text, model, tokenizer):
    """对一段 <=256 字的文本恢复标点"""
    import torch

    if not text.strip():
        return text

    enc = tokenizer(text, return_tensors="pt", truncation=True, max_length=510)
    with torch.no_grad():
        logits = model(**enc).logits
    pred_ids = logits.argmax(-1)[0].tolist()

    id2label = model.config.id2label
    tokens = tokenizer.convert_ids_to_tokens(enc["input_ids"][0])

    out = []
    for tok, pid in zip(tokens, pred_ids):
        if tok in ("[CLS]", "[SEP]", "[PAD]"):
            continue
        # 还原 wordpiece
        if tok.startswith("##"):
            tok = tok[2:]
        out.append(tok)
        label = id2label.get(pid, "O") if isinstance(id2label, dict) else id2label[pid]
        if label != "O":
            # 标签形如 "，" "。" "？" 或 "B-，" 等
            punct = label.split("-")[-1]
            if punct in "，。！？；：、":
                out.append(punct)
    return "".join(out)


def restore_punctuation(text):
    """
    给无标点中文长文本恢复标点。
    返回带标点文本；失败返回 None。
    """
    try:
        model, tokenizer = _load()
    except Exception:
        return None

    # 去掉已有的空白
    text = re.sub(r"\s+", "", text)
    if not text:
        return None

    # 分块处理（每块 200 字，避免超长）
    chunk_size = 200
    chunks = [text[i:i + chunk_size] for i in range(0, len(text), chunk_size)]

    results = []
    for chunk in chunks:
        try:
            results.append(_restore_chunk(chunk, model, tokenizer))
        except Exception:
            results.append(chunk)

    return "".join(results)


def format_paragraphs(text, sentences_per_para=5):
    """按句末标点分段，每 N 句一段"""
    text = re.sub(r"([。！？!?])\s*", r"\1\n", text.strip())
    lines = [l.strip() for l in text.splitlines() if l.strip()]
    paragraphs, group = [], []
    for line in lines:
        group.append(line)
        if len(group) >= sentences_per_para:
            paragraphs.append("".join(group))
            group = []
    if group:
        paragraphs.append("".join(group))
    return "\n\n".join(paragraphs)


if __name__ == "__main__":
    sample = "大家好欢迎来到今天的视频今天我们来讲讲人工智能的发展趋势这个话题非常重要你觉得呢首先我们看看大语言模型其次是多模态技术最后聊聊应用场景"
    result = restore_punctuation(sample)
    print("原文:", sample)
    print("结果:", result)
    if result:
        print("分段:")
        print(format_paragraphs(result, 3))
